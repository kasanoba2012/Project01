package edu.android.project01.Second;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import org.w3c.dom.Text;

import edu.android.project01.R;

/**
 * A simple {@link Fragment} subclass.
 */
public class SecondPsyActivity1Button8 extends Fragment {

    static TextView textView200;
    static public String message100;

    public SecondPsyActivity1Button8() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        ViewGroup rootView = (ViewGroup) inflater.inflate(R.layout.fragment_second_psy_activity1_button8, container, false);

        textView200 = rootView.findViewById(R.id.textView200);
        message100 = (String) textView200.getText();

        return rootView;
    }

    public String getData1() {

        return message100;
    }

}
