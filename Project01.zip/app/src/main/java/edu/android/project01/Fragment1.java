package edu.android.project01;


import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;

import java.util.ArrayList;

import edu.android.project01.First.PsyAcivity1;
import edu.android.project01.FirstFragment.FirstFragmentFirst;
import edu.android.project01.FirstFragment.FirstFragmentFourth;
import edu.android.project01.FirstFragment.FirstFragmentSecond;
import edu.android.project01.FirstFragment.FirstFragmentThird;


/**
 * A simple {@link Fragment} subclass.
 */
public class Fragment1 extends Fragment {


    Fragment1 fragment1;
    Fragment2 fragment2;
    Fragment3 fragment3;
    FirstFragmentSecond fragmentSecond;
    FirstFragmentFirst fragmentFirst;
    FirstFragmentThird fragmentThird;
    FirstFragmentFourth fragmentFourth;


    public Fragment1() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(final LayoutInflater inflater, final ViewGroup container,
                             Bundle savedInstanceState) {

        ViewGroup rootView = (ViewGroup) inflater.inflate(R.layout.fragment1, container, false);


        Spinner spinner = rootView.findViewById(R.id.spinner);

        ArrayList arrayList = new ArrayList<>();
        arrayList.add("사랑/연예");
        arrayList.add("성격/성향");
        arrayList.add("일/스트레스");
        arrayList.add("기타");


        fragment1 = new Fragment1();
        fragment2 = new Fragment2();
        fragment3 = new Fragment3();
        fragmentSecond = new FirstFragmentSecond();
        fragmentFirst = new FirstFragmentFirst();
        fragmentThird = new FirstFragmentThird();
        fragmentFourth = new FirstFragmentFourth();

        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<>(getContext(), android.R.layout.simple_spinner_dropdown_item, arrayList);
        spinner.setAdapter(arrayAdapter);

        final FragmentManager fragmentManager = getChildFragmentManager();

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                Log.d("Fragment1","뭐가 클릭 되나 ?" + position);
                // position 0,1,2,3에 따라서 다른 화면을 보여주기
                switch (position) {
                    case 0:
                        Log.d("Fragment1","0번 클릭됨");
                        fragmentManager.beginTransaction().replace(R.id.view1, fragmentFirst).commit();
                        break;
                    case 1:
                        Log.d("Fragment1","1번 클릭됨");
                        fragmentManager.beginTransaction().replace(R.id.view1, fragmentSecond).commit();
                        break;
                    case 2:
                        Log.d("Fragment1","2번 클릭됨");
                        fragmentManager.beginTransaction().replace(R.id.view1, fragmentThird).commit();
                        break;
                    case 3:
                        Log.d("Fragment1","3번 클릭됨");
                        fragmentManager.beginTransaction().replace(R.id.view1, fragmentFourth).commit();
                        break;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        Button button1 = rootView.findViewById(R.id.button30);
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d("Fragment1","Fragment1 첫번째 버튼 클릭");
                Intent intent = new Intent(getActivity(), PsyAcivity1.class);
                startActivity(intent);

            }
        });

        return rootView;
    }

}
