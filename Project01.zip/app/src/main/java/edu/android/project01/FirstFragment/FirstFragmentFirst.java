package edu.android.project01.FirstFragment;


import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import edu.android.project01.First.PsyAcivity1;
import edu.android.project01.R;

/**
 * A simple {@link Fragment} subclass.
 */
public class FirstFragmentFirst extends Fragment {


    public FirstFragmentFirst() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        ViewGroup rootView = (ViewGroup) inflater.inflate(R.layout.fragment_first_fragment_first, container, false);

        Button button1 = rootView.findViewById(R.id.button30);
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d("Fragment1","Fragment1 첫번째 버튼 클릭");
                Intent intent = new Intent(getActivity(), PsyAcivity1.class);
                startActivityForResult(intent,101);

            }
        });

        return rootView;
    }

}
