package edu.android.project01;

import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.Log;

import edu.android.project01.First.PsyActivityFragmentButton1;

// 탭(Tab) : 탭을 누를 때 마다 내용이 보이는 화면 영역이 전환
// - 내비게이션 위젯이라고 불림
// - 상단 탭과 하단 탭이 존재
// - design 라이브러리를 추가
public class MainActivity extends AppCompatActivity {
    Toolbar toolbar;

    Fragment1 fragment1;
    Fragment2 fragment2;
    Fragment3 fragment3;
    PsyActivityFragmentButton1 psyActivityFragmentButton1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        ActionBar actionBar = getSupportActionBar(); // 액션바 객체 참조
        actionBar.setDisplayShowTitleEnabled(false); // 액션바에 타이틀 보이기 설정

        fragment1 = new Fragment1();
        fragment2 = new Fragment2();
        fragment3 = new Fragment3();

        psyActivityFragmentButton1 = new PsyActivityFragmentButton1();

        FragmentManager fragmentManager = getSupportFragmentManager();
        fragmentManager.beginTransaction().replace(R.id.container, fragment1).commit();

        // 탭 레이아웃 객체 참조
        TabLayout tabs = findViewById(R.id.tabs);
        // 탭 레이아웃에 탭 추가
        tabs.addTab(tabs.newTab().setText("심리테스트"));
        tabs.addTab(tabs.newTab().setText("문제적남자 퀴즈"));
        tabs.addTab(tabs.newTab().setText("아직 뭐할지 모름?.."));

        tabs.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                int position = tab.getPosition();
                Log.d("MainActivity", "선택된 탭 : " + position);

                FragmentManager fragmentManager = getSupportFragmentManager();

                switch (position) {
                    case 0:
                        Log.d("MainActivity", "MainActivity 첫번째 버튼 클릭");
                        fragmentManager.beginTransaction().replace(R.id.container, fragment1).commit();
                        break;
                    case 1:
                        fragmentManager.beginTransaction().replace(R.id.container, fragment2).commit();
                        break;
                    case 2:
                        fragmentManager.beginTransaction().replace(R.id.container, fragment3).commit();
                        break;
                }
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });

    } // end onCreate()
} // endMainActivity
