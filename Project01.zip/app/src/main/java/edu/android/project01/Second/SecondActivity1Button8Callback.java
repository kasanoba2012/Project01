package edu.android.project01.Second;

public interface SecondActivity1Button8Callback {
    public String returnData();
}
