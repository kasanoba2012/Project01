package edu.android.project01.Second2;

import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import edu.android.project01.Drawing.Drawing1;
import edu.android.project01.R;

public class QuizActivity120 extends AppCompatActivity{

    TextView textView1;
    TextView textView2;
    TextView textView3;
    TextView textView4;

    Button button1;
    Button button2;
    Button button3;
    Button button4;
    Button button5;
    Button button6;
    Button button7;

    ImageView imageView1;
    ImageView imageView2;
    ImageView imageView3;


    int sw1 = 0;

    // 타이머 필요 변수
    int value=0;
    TextView mText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz120);

        // 타이머 표시 할당 및 타이머 시작
        mText=(TextView)findViewById(R.id.textView13);
        mHandler.sendEmptyMessage(0); // 앱 시작과 동시에 핸들러에 메세지 전달

        button1 = findViewById(R.id.button30); // 1번 정답 확인 버튼
        button2 = findViewById(R.id.button15); // 그림판으로 가기 버튼
        button3 = findViewById(R.id.button14); // 뒤로 돌아가기 버튼
        button4 = findViewById(R.id.button21); // 동영상 보기 버튼
        button5 = findViewById(R.id.button); // 2번 정답 확인 버튼
        button6 = findViewById(R.id.button17); // 문제 1번 정답 체크
        button7 = findViewById(R.id.button18); // 문제 2번 정답 체크


        textView1 = findViewById(R.id.textView6);
        textView2 = findViewById(R.id.textView10);
        textView3 = findViewById(R.id.textView11); // 내가 쓴 정답 1번
        textView4 = findViewById(R.id.textView12); // 내가 쓴 정답 2번

        imageView1 = findViewById(R.id.imageView3);
        imageView2 = findViewById(R.id.imageView5);
        imageView3 = findViewById(R.id.imageView4);



        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                switch (sw1){
                    case 0:
                        button1.setText("문제1 정답 접기");
                        textView1.setVisibility(View.VISIBLE);
                        imageView1.setVisibility(View.VISIBLE);
                        imageView2.setVisibility(View.VISIBLE);
                        textView2.setVisibility(View.VISIBLE);
                        imageView3.setVisibility(View.VISIBLE);
                        sw1 = 1;
                        break;
                    case 1:
                        button1.setText("문제1 정답 확인");
                        textView1.setVisibility(View.INVISIBLE);
                        imageView1.setVisibility(View.INVISIBLE);
                        imageView2.setVisibility(View.INVISIBLE);
                        textView2.setVisibility(View.INVISIBLE);
                        imageView3.setVisibility(View.INVISIBLE);
                        sw1 = 0;
                        break;
                }
            }
        });


        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), Drawing1.class);
                startActivityForResult(intent,101);
            }
        });

        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        button4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d("QuizActivity120","동영상 보기 버튼 클릭 ");
                Intent intent = new Intent(getApplicationContext(), QuizActivityYoutube120.class);
                startActivityForResult(intent,101);
            }
        });

        button5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                switch (sw1){
                    case 0:
                        button5.setText("문제2 정답 접기");
                        textView1.setVisibility(View.VISIBLE);
                        imageView1.setVisibility(View.VISIBLE);
                        imageView2.setVisibility(View.VISIBLE);
                        textView2.setVisibility(View.VISIBLE);
                        imageView3.setVisibility(View.VISIBLE);
                        sw1 = 1;
                        break;
                    case 1:
                        button5.setText("문제2 정답 확인");
                        textView1.setVisibility(View.INVISIBLE);
                        imageView1.setVisibility(View.INVISIBLE);
                        imageView2.setVisibility(View.INVISIBLE);
                        textView2.setVisibility(View.INVISIBLE);
                        imageView3.setVisibility(View.INVISIBLE);
                        sw1 = 0;
                        break;
                }

            }
        });

        button6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 키보드 내리는 부분
                InputMethodManager imm = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
                imm.hideSoftInputFromWindow(textView3.getWindowToken(), 0);

                if (textView3.getText().toString().equalsIgnoreCase("five")) {
                    Log.d("QuizActivity120", "정답입니다" + textView3.getText());
                    Toast.makeText(getApplicationContext(),"정답입니다.",Toast.LENGTH_LONG).show();
                } else {
                    Log.d("QuizActivity120", "오답입니다 : " + textView3.getText());
                    Toast.makeText(getApplicationContext(),"오답입니다.",Toast.LENGTH_LONG).show();
                }
            }
        });


        button7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 키보드 내리는 부분
                InputMethodManager imm = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
                imm.hideSoftInputFromWindow(textView4.getWindowToken(), 0);

                if (textView4.getText().toString().equalsIgnoreCase("ㅎ")) {
                    Log.d("QuizActivity120", "정답입니다" + textView4.getText());
                    Toast.makeText(getApplicationContext(),"정답입니다.",Toast.LENGTH_LONG).show();
                } else {
                    Log.d("QuizActivity120", "오답입니다 : " + textView4.getText());
                    Toast.makeText(getApplicationContext(),"오답입니다.",Toast.LENGTH_LONG).show();
                }
            }
        });


    }

    // 타이머 메소드
    Handler mHandler = new Handler() {
        public void handleMessage(Message msg) {
            value++;
            mText.setText("현재 경과 시간 " + value + " 초");
            if(value==120) {
                Toast.makeText(getApplicationContext(),"1분이 경과 되어 종료 됩니다.",Toast.LENGTH_LONG).show();
                finish();
            }
            Log.d("QuizActivity120", "반복중 value 값 : " + value);

            // 메세지를 처리하고 또다시 핸들러에 메세지 전달 (1000ms 지연)
            mHandler.sendEmptyMessageDelayed(0,1000);
        }
    };

    private void timerStop () {
        mHandler.removeMessages(0);
    }
}
