package edu.android.project01.Second;

import android.content.Intent;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ScrollView;
import android.widget.TextView;

import edu.android.project01.First.PsyActivityFragmentButton1;
import edu.android.project01.R;

public class SecondPsyActivity1 extends AppCompatActivity implements SecondActivity1Button8Callback{

    SecondPsyActivity1Button1 secondPsyActivity1Button1;
    SecondPsyActivity1Button2 secondPsyActivity1Button2;
    SecondPsyActivity1Button3 secondPsyActivity1Button3;
    SecondPsyActivity1Button4 secondPsyActivity1Button4;
    SecondPsyActivity1Button5 secondPsyActivity1Button5;
    SecondPsyActivity1Button8 secondPsyActivity1Button8;

    Button button1;
    Button button2;
    Button button3;
    Button button4;
    Button button5;
    Button button6;
    Button button7;
    Button button8;
    Button button9;

    String testmin;

    TextView textView;

    ScrollView scrollView1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second_psy1);

        final Button button1 = findViewById(R.id.button1);
        final Button button2 = findViewById(R.id.button2);
        final Button button3 = findViewById(R.id.button3);
        final Button button4 = findViewById(R.id.button4);
        final Button button8 = findViewById(R.id.button16);


        final Button button5 = findViewById(R.id.button5);
        Button button6 = findViewById(R.id.button6);
        Button button7 = findViewById(R.id.button7);
        button9 = findViewById(R.id.button8);

        secondPsyActivity1Button1 = new SecondPsyActivity1Button1();
        secondPsyActivity1Button2 = new SecondPsyActivity1Button2();
        secondPsyActivity1Button3 = new SecondPsyActivity1Button3();
        secondPsyActivity1Button4 = new SecondPsyActivity1Button4();
        secondPsyActivity1Button5 = new SecondPsyActivity1Button5();
        secondPsyActivity1Button8 = new SecondPsyActivity1Button8();

        textView = findViewById(R.id.textView4);

        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 1번 정답창으로 이동하기
                Log.d("SecondPsyActivity1", "SecondPsyActivity1.class 호출 / button01 눌림");
                FragmentManager fragmentManager = getSupportFragmentManager();
                fragmentManager.beginTransaction().replace(R.id.container, secondPsyActivity1Button1).commit();
            }
        });

        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 1번 정답창으로 이동하기
                Log.d("SecondPsyActivity1", "SecondPsyActivity1.class 호출 / button02 눌림");
                FragmentManager fragmentManager = getSupportFragmentManager();
                fragmentManager.beginTransaction().replace(R.id.container, secondPsyActivity1Button2).commit();
            }
        });

        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 1번 정답창으로 이동하기
                Log.d("SecondPsyActivity1", "SecondPsyActivity1.class 호출 / button03 눌림");
                FragmentManager fragmentManager = getSupportFragmentManager();
                fragmentManager.beginTransaction().replace(R.id.container, secondPsyActivity1Button3).commit();
            }
        });

        button4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 1번 정답창으로 이동하기
                Log.d("SecondPsyActivity1", "SecondPsyActivity1.class 호출 / button04 눌림");
                FragmentManager fragmentManager = getSupportFragmentManager();
                fragmentManager.beginTransaction().replace(R.id.container, secondPsyActivity1Button4).commit();
            }
        });

        button8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 1번 정답창으로 이동하기
                Log.d("SecondPsyActivity1", "SecondPsyActivity1.class 호출 / button08 눌림");
                FragmentManager fragmentManager = getSupportFragmentManager();
                fragmentManager.beginTransaction().replace(R.id.container, secondPsyActivity1Button5).commit();
            }
        });

        button5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d("SecondPsyActivity1", "SecondPsyActivity1.class 호출 / button05 눌림");
                FragmentManager fragmentManager = getSupportFragmentManager();
                fragmentManager.beginTransaction().replace(R.id.container, secondPsyActivity1Button8).commit();
            }
        });


        button6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        button7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 카톡으로 보내는 기능
                String message = textView.getText().toString() + "\n\n" +
                        "A. " + button1.getText().toString() + "\n"+
                        "B. " + button2.getText().toString() + "\n"+
                        "C. " + button3.getText().toString() + "\n"+
                        "D. " + button4.getText().toString() + "\n"+
                        "E. " + button8.getText().toString();
                Intent intent = new Intent(Intent.ACTION_SEND);
                intent.setType("text/plain");
                intent.putExtra(Intent.EXTRA_TEXT, message );
                intent.setPackage("com.kakao.talk");
                startActivity(intent);
            }
        });

        button9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                // SecondPsyActivity1Button8여기에 있는 textView의 text 가져오기
                returnData();
                Log.d("SecondPsyActivity1", "버튼9 : " + testmin);
                String message = testmin;

                Intent intent = new Intent(Intent.ACTION_SEND);
                intent.setType("text/plain");
                intent.putExtra(Intent.EXTRA_TEXT, message );
                intent.setPackage("com.kakao.talk");
                startActivity(intent);
            }
        });

    }


    @Override
    public String returnData() {
        testmin = secondPsyActivity1Button8.message100;

        Log.d("SecondPsyActivity1", "여기는 뭐야 ? : " + testmin);
        return testmin;
    }
}
