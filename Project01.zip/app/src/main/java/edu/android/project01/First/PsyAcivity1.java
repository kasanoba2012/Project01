package edu.android.project01.First;

import android.content.Intent;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import edu.android.project01.R;

public class PsyAcivity1 extends AppCompatActivity {

    PsyActivityFragmentButton1 psyActivityFragmentButton1;
    PsyActivityFragmentButton2 psyActivityFragmentButton2;
    PsyActivityFragmentButton3 psyActivityFragmentButton3;
    PsyActivityFragmentButton4 psyActivityFragmentButton4;
    PsyActivityFragmentButton5 psyActivityFragmentButton5;

    TextView textView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_psy_acivity1);

        Log.d("PsyAcivity1", "PsyAcivity1.class 호출됨");

        final Button button1 = findViewById(R.id.button1);
        final Button button2 = findViewById(R.id.button2);
        final Button button3 = findViewById(R.id.button3);
        final Button button4 = findViewById(R.id.button4);
        Button button5 = findViewById(R.id.button5); // 전체 답 확인
        Button button6 = findViewById(R.id.button6); // 이전 화면으로 돌아가기
        Button button7 = findViewById(R.id.button7); // 카톡으로 전달

        textView = findViewById(R.id.textView4);

        psyActivityFragmentButton1 = new PsyActivityFragmentButton1();
        psyActivityFragmentButton2 = new PsyActivityFragmentButton2();
        psyActivityFragmentButton3 = new PsyActivityFragmentButton3();
        psyActivityFragmentButton4 = new PsyActivityFragmentButton4();
        psyActivityFragmentButton5 = new PsyActivityFragmentButton5();

//        FragmentManager fragmentManager = getSupportFragmentManager();
//        fragmentManager.beginTransaction().replace(R.id.container, test1).commit();

        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 1번 정답창으로 이동하기
                Log.d("PsyAcivity1", "PsyAcivity1.class 호출 / button01 눌림");
                FragmentManager fragmentManager = getSupportFragmentManager();
                fragmentManager.beginTransaction().replace(R.id.container, psyActivityFragmentButton1).commit();
            }
        });

        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d("PsyAcivity1", "PsyAcivity1.class 호출 / button02 눌림");
                FragmentManager fragmentManager = getSupportFragmentManager();
                fragmentManager.beginTransaction().replace(R.id.container, psyActivityFragmentButton2).commit();
            }
        });

        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d("PsyAcivity1", "PsyAcivity1.class 호출 / button03 눌림");
                FragmentManager fragmentManager = getSupportFragmentManager();
                fragmentManager.beginTransaction().replace(R.id.container, psyActivityFragmentButton3).commit();
            }
        });

        button4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d("PsyAcivity1", "PsyAcivity1.class 호출 / button04 눌림");
                FragmentManager fragmentManager = getSupportFragmentManager();
                fragmentManager.beginTransaction().replace(R.id.container, psyActivityFragmentButton4).commit();
            }
        });

        button5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d("PsyAcivity1", "PsyAcivity1.class 호출 / button05 눌림");
                FragmentManager fragmentManager = getSupportFragmentManager();
                fragmentManager.beginTransaction().replace(R.id.container, psyActivityFragmentButton5).commit();
            }
        });


        button6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d("PsyAcivity1", "PsyAcivity1.class 호출 / button06 눌림");
                finish();
            }
        });

        button7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d("PsyAcivity1", "PsyAcivity1.class 호출 / button07 눌림");
                Log.d("PsyAcivity1", "getText : 확인 되나 ? " + textView.getText());

                // 카톡으로 보내는 기능
                String message = textView.getText().toString() + "\n\n" +
                        "A. " + button1.getText().toString() + "\n"+
                        "B. " + button2.getText().toString() + "\n"+
                        "C. " + button3.getText().toString() + "\n"+
                        "D. " + button4.getText().toString();
                Intent intent = new Intent(Intent.ACTION_SEND);
                intent.setType("text/plain");
                intent.putExtra(Intent.EXTRA_TEXT, message );
                intent.setPackage("com.kakao.talk");
                startActivity(intent);
            }
        });
    }
}
