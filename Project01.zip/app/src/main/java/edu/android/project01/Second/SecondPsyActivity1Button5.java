package edu.android.project01.Second;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import edu.android.project01.R;

/**
 * A simple {@link Fragment} subclass.
 */
public class SecondPsyActivity1Button5 extends Fragment {


    public SecondPsyActivity1Button5() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_second_psy_activity1_button5, container, false);
    }

}
